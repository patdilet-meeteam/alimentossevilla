# Evidencia de pruebas del kit

Ejecución sobre la base temporal `alimentossevilla_import_kit_test`, creada para este trabajo y migrada con los 10 archivos oficiales de `prisma/migrations`. No se usó `alimentossevilla` original ni producción.

- **Preflight offline:** PASS; sin códigos duplicados ni dependencias irresueltas.
- **Dry run final:** PASS, `DRY_RUN_PASS`; 430 ingredientes, 39 productos, 63 presentaciones, 51 nutrientes, 18 perfiles, 17 formulaciones, 18 versiones DRAFT, 275 componentes; la transacción revirtió todo. Conteo tras dry run: 0 nutrientes, 0 ingredientes, 0 productos.
- **Apply:** PASS en DB aislada; creó los registros esperados con transacción serializable y respaldo verificado.
- **Reapply:** PASS; creó cero filas nuevas y reconoció todas las filas como idénticas (51 nutrientes, 430 ingredientes, 39 productos, 63 presentaciones, 17 formulaciones, 18 versiones, 18 perfiles, 306 valores nutricionales, 275 componentes).
- **Colisión natural tardía:** PASS como guardia; se insertó fixture incompatible para producto `cervecero`, el importador respondió `ABORTED_NO_COMMIT` / `Natural-key collision on products`, y la transacción revirtió los 51 nutrientes y 430 ingredientes previos. Solo quedó la fila fixture preexistente (conteos: 0 nutrientes, 0 ingredientes, 1 producto).
- **Puerta de respaldo ausente:** PASS como guardia; sin archivo/SHA aborta antes de conectarse a Prisma.
- **Digest:** SHA-256 del dump de prueba se verificó con `pg_restore -l`; para producción, el operador debe generar un dump nuevo y pasar su digest.

No se probó contra producción ni se pudo verificar allí el conjunto de 39 códigos UI. El resultado de una carga en producción depende de que se ejecute primero el dry run contra el destino correcto; cualquier discrepancia aborta.
