# Validación del kit de migración

## Revisión de esta versión — 13 oct 2026

- **Payload normalizado:** PASS. El catálogo se redujo de 51 a 17 claves canónicas; las 306 referencias de nutrientes en los 18 perfiles resuelven a esas claves. Las definiciones coinciden con el catálogo del repositorio, incluido ZINC no obligatorio.
- **Preflight offline:** PASS. 430 ingredientes, 39 productos, 63 presentaciones, 17 nutrientes, 18 perfiles, 17 formulaciones, 18 versiones DRAFT y 275 componentes; sin claves duplicadas, dependencias faltantes ni claves de nutrientes sin usar.
- **Sintaxis y contrato CLI:** PASS (node --check). Las pruebas aceptaron URL HTTPS, URL con slash raíz y hostname; rechazaron HTTP, host incorrecto y rutas adicionales antes de revisar el respaldo.
- **Integridad del archivo:** cada archivo del paquete se verifica contra SHA256SUMS.json; el SHA-256 del ZIP se publica en el README externo.

## Validación transaccional anterior

El 9 oct 2026, la versión anterior del paquete (51 claves de nutrientes) pasó dry run, apply, reapply idempotente y prueba de rollback ante colisión en una base PostgreSQL desechable. Esa ejecución valida la transacción del importador anterior; no certifica el catálogo ni el payload normalizados de esta versión.

No se pudo repetir la prueba con PostgreSQL desechable para esta versión: Docker falló al inicializar el contenedor temporal con “No space left on device”. No se modificó la base local persistente ni se conectó a producción. **El operador debe ejecutar y revisar un dry run del ZIP actual antes de añadir --apply.** La prueba offline no valida la identidad ni el contenido de la base de producción.
