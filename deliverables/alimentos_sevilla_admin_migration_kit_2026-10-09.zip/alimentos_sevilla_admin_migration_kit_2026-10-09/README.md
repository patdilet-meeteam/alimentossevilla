# Alimentos Sevilla — paquete aditivo para operación administrada

Paquete de datos saneados y un importador transaccional para que un operador autorizado lo ejecute desde el repositorio. **Dry run es el modo predeterminado; solo `--apply` escribe.** La lógica transaccional tuvo pruebas anteriores en una base desechable; el payload de esta revisión pasó las validaciones offline. El alcance y las limitaciones de cada prueba están en `TEST-RESULTS.md`. No se conectó a producción.

## Alcance y origen

Snapshot PostgreSQL local de solo lectura: `2026-10-09T14:25:53.756635Z`. Incluye 430 ingredientes activos, 39 productos activos, 63 presentaciones activas, 17 claves canónicas de nutrientes referenciadas por 18 perfiles con procedencia explícita `TN OFICIAL` (306 valores), 17 formulaciones, 18 versiones y 275 componentes. La carga solo inserta códigos ausentes; un código presente con datos diferentes detiene y revierte toda la transacción. Coincidencias exactas se conservan y cuentan como idempotentes. No hace upsert de actualización, delete ni truncate.

El catálogo importado contiene solo las 17 claves canónicas utilizadas por los 306 valores de perfil. Se omitieron 34 claves del snapshot que no son referenciadas por esos perfiles, incluidas etiquetas españolas alternativas. Las definiciones vienen del catálogo canónico del repositorio; `ZINC` queda como no obligatorio en etiqueta. Si producción tiene una definición diferente, el importador detiene y revierte la operación.

## Exclusiones / tratamiento explícito

- 10 perfiles demo, 123 perfiles con `sourceDetail` vacío/ambiguo y cualquier perfil sin `TN OFICIAL` explícito.
- Productos `tocineta-faizan-1000` y `tocineta-faizan-150`, sus 2 presentaciones y relaciones derivadas: tienen vínculo explícito con formulaciones de procedencia demo. No se ofrecen como datos empresariales reales.
- Dos versiones aprobadas con procedencia demo.
- La versión `salchicha-desayuno-premium-480` v3 tenía estado fuente `APPROVED` y motivo de autorización documentado. `payload.json` conserva `sourceStatus` y manifiesto de conversión, pero el destino la recibe como `DRAFT`, sin aprobador ni fecha de aprobación. La aprobación no se transfiere; exige el workflow normal en destino.
- La única importación de costos está `SUPERSEDED`; se excluyen costos/historial completo y no se aplican.
- La versión de parámetros regulatorios no se cambia ni importa.
- Usuarios, correos, hashes, sesiones, tokens y auditoría general no se copian.

Los conteos de documentación 90 ingredientes/106 productos son objetivos, no conteos almacenados. El esquema no tiene `tenantId`/`organizationId`; si el destino posee columna tenant/organization el importador aborta. Los dos códigos Tocineta se excluyen por procedencia, no porque exista una selección confirmada de 90/106.

## Requisitos del operador

Solicita autorización del dueño de la carga y confirma quién validará el resultado. El dry run puede prepararse antes de la ventana; `--apply` requiere además una ventana confirmada de 30 minutos sin usuarios.

- Ejecutar desde la raíz del checkout autorizado de Alimentos Sevilla, con Prisma Client generado y migraciones del paquete presentes.
- Node.js, `DATABASE_URL` y `pg_restore` disponibles en el host operador; la URL de base nunca se imprime.
- `--confirm-application` acepta la URL HTTPS completa `https://nutricional.alimentossevilla.digital` o el hostname `nutricional.alimentossevilla.digital`; en ambos casos se valida el origen de producción exacto.
- Antes de operar, confirmar con el administrador la ruta real del proyecto, archivo Compose, archivo de entorno, servicio PostgreSQL, nombre de base y host. Se mencionó `/opt/nutricional`, pero no se asume esa ruta ni que el servicio se llame `db`. No copiar secretos a chats ni logs.
- Respaldar la base destino antes de **cada** corrida, incluso dry run. Ejemplo en el servidor Compose; sustituir el path por ruta protegida:

```sh
umask 077
# Sustituye estos valores por la configuración confirmada; no adivines nombres.
COMPOSE_FILE=/ruta/confirmada/docker-compose.yml
ENV_FILE=/ruta/confirmada/.env
DB_SERVICE=servicio_postgres_confirmado
docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" config --services
docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" exec -T "$DB_SERVICE" \
  sh -lc 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > /secure/path/alimentos-sevilla-preimport.dump
sha256sum /secure/path/alimentos-sevilla-preimport.dump
pg_restore -l /secure/path/alimentos-sevilla-preimport.dump | head
```

La redirección > guarda el dump donde se ejecuta el shell. Si la copia se corre dentro de SSH en el servidor, transfiere el archivo a almacenamiento protegido fuera del servidor antes de aplicar cambios. Verifica que `pg_restore -l` lo lea desde la máquina donde correrá el script. El operador calcula el SHA-256 localmente y sustituye los placeholders; no comparte `DATABASE_URL` ni secretos.

## Ejecución

Primero dry run (lee el destino y rollbackea toda su transacción):

```sh
DATABASE_URL="$DATABASE_URL" node /ruta/al/kit/tools/import-safe.cjs \
  --confirm-application nutricional.alimentossevilla.digital \
  --expect-host HOST_DB_CONFIRMADO --expect-db BASE_CONFIRMADA \
  --backup /secure/path/alimentos-sevilla-preimport.dump \
  --backup-sha256 SHA256_CALCULADO
```

Revisar el informe completo: destino, conteos, existentes idénticos, filas nuevas y exclusiones. Si no termina con `DRY_RUN_PASS`, detenerse. La escritura requiere autorización expresa del dueño de la carga, nombre de la persona validadora y ventana sin usuarios; luego se genera otro respaldo y se añade `--apply`:

```sh
DATABASE_URL="$DATABASE_URL" node /ruta/al/kit/tools/import-safe.cjs \
  --confirm-application nutricional.alimentossevilla.digital \
  --expect-host HOST_DB_CONFIRMADO --expect-db BASE_CONFIRMADA \
  --backup /secure/path/alimentos-sevilla-preimport.dump \
  --backup-sha256 SHA256_CALCULADO --apply
```

La carga aplica una transacción serializable completa. En cualquier error, Prisma revierte la transacción y reporta `ABORTED_NO_COMMIT`. Confirmar `APPLIED` solo cuando el CLI termine con éxito; volver a correr exige un nuevo backup y debe contar las filas ya idénticas sin crear duplicados.

## Guardas y límites

El importador compara hostname/base con valores de confirmación explícitos, exige la identidad de aplicación, archivo custom-format legible, SHA-256 correcto y nombre de base del dump; exige las 10 migraciones versionadas del repo y verifica que el esquema no sea tenantizado. Códigos SIESA e internos son claves de deduplicación. Si los 39 productos UI no coinciden exactamente con los 39 códigos fuente, si cualquier valor del código existente difiere, si hay referencias de ingredientes sin match o perfil ambiguo, la transacción se aborta. No fuerza compatibilidad de negocio ni corrige unidades.

No incluye ni modifica código del repo. No ejecuta seeds demo, no crea aprobaciones, no importa los parámetros regulatorios ni los costos. El rol/fila de producto de destino debe ser compatible con el schema Prisma del checkout; la guarda de migraciones rechaza una versión distinta. Pruebas offline no certifican acceso a producción, identidad real del host ni coincidencia de los 39 productos UI.

El repositorio tiene un remoto `meeteam` con visibilidad pública confirmada y un remoto `origin` que GitHub no resolvió al consultar metadatos. Por eso el paquete y sus datos se mantienen como archivo privado en Library; no se añade el dataset ni el script a esos remotos.
