# Alimentos Sevilla — paquete aditivo para operación administrada

Paquete de datos saneados y un importador transaccional para que un operador con acceso a producción lo ejecute desde el repositorio. **Dry run es el modo predeterminado; solo `--apply` escribe.** Se probó con las migraciones reales del repo en la base temporal `alimentossevilla_import_kit_test`; nunca contra la base local original ni producción.

## Alcance y origen

Snapshot PostgreSQL local de solo lectura: `2026-10-09T14:25:53.756635Z`. Incluye 430 ingredientes activos, 39 productos activos, 63 presentaciones activas, 51 claves de nutrientes, 18 perfiles con procedencia explícita `TN OFICIAL` (306 valores), 17 formulaciones, 18 versiones y 275 componentes. La carga solo inserta códigos ausentes; un código presente con datos diferentes detiene y revierte toda la transacción. Coincidencias exactas se conservan y cuentan como idempotentes. No hace upsert de actualización, delete ni truncate.

## Exclusiones / tratamiento explícito

- 10 perfiles demo, 123 perfiles con `sourceDetail` vacío/ambiguo y cualquier perfil sin `TN OFICIAL` explícito.
- Productos `tocineta-faizan-1000` y `tocineta-faizan-150`, sus 2 presentaciones y relaciones derivadas: tienen vínculo explícito con formulaciones de procedencia demo. No se ofrecen como datos empresariales reales.
- Dos versiones aprobadas con procedencia demo.
- La versión `salchicha-desayuno-premium-480` v3 tenía estado fuente `APPROVED` y motivo de autorización documentado. `payload.json` conserva `sourceStatus` y manifiesto de conversión, pero el destino la recibe como `DRAFT`, sin aprobador ni fecha de aprobación. La aprobación no se transfiere; exige el workflow normal en destino.
- La única importación de costos está `SUPERSEDED`; se excluyen costos/historial completo y no se aplican.
- La versión de parámetros regulatorios no se cambia ni importa.
- Usuarios, correos, hashes, sesiones, tokens y auditoría general no se copian.

Los conteos de documentación 90 ingredientes/106 productos son objetivos, no conteos almacenados. El esquema no tiene `tenantId`/`organizationId`; si el destino posee columna tenant/organization el importador aborta. Los dos códigos Tocineta se excluyen por procedencia, no porque exista una selección confirmada de 90/106.

## Requisitos del operador

- Ejecutar desde la raíz del checkout autorizado de Alimentos Sevilla, con Prisma Client generado y migraciones del paquete presentes.
- Node.js, variables `DATABASE_URL` y `pg_restore` disponibles en el host operador. `DATABASE_URL` nunca se imprime.
- Acceso solo al destino indicado. Confirma la identidad del VPS/base por su canal administrativo antes de elegir `--expect-host` y `--expect-db`.
- Respaldar la base destino antes de **cada** corrida, incluso dry run. Ejemplo en el servidor Compose; sustituir el path por ruta protegida:

```sh
umask 077
# Ejecutar en el servidor de producción; la tubería escribe el archivo local del operador.
docker compose -f docker-compose.prod.yml --env-file .env.production exec -T db \
  sh -lc 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > /secure/path/alimentos-sevilla-preimport.dump
sha256sum /secure/path/alimentos-sevilla-preimport.dump
pg_restore -l /secure/path/alimentos-sevilla-preimport.dump | head
```

El operador debe copiar el SHA-256 calculado y sustituir todos los placeholders. No poner la URL completa en argumentos/logs compartidos. `pg_restore` debe poder leer el dump desde la máquina donde corre el script.

## Ejecución

Primero dry run (lee el destino y rollbackea toda su transacción):

```sh
DATABASE_URL="$DATABASE_URL" node /ruta/al/kit/tools/import-safe.cjs \
  --confirm-application nutricional.alimentossevilla.digital \
  --expect-host HOST_DB_CONFIRMADO --expect-db BASE_CONFIRMADA \
  --backup /secure/path/alimentos-sevilla-preimport.dump \
  --backup-sha256 SHA256_CALCULADO
```

Revisar el informe: conteos, existentes idénticos, filas nuevas, exclusiones y destino. La escritura requiere explícitamente repetir luego del respaldo actualizado y añadir `--apply`:

```sh
DATABASE_URL="$DATABASE_URL" node /ruta/al/kit/tools/import-safe.cjs \
  --confirm-application nutricional.alimentossevilla.digital \
  --expect-host HOST_DB_CONFIRMADO --expect-db BASE_CONFIRMADA \
  --backup /secure/path/alimentos-sevilla-preimport.dump \
  --backup-sha256 SHA256_CALCULADO --apply
```

La carga aplica una transacción serializable completa. En cualquier error, Prisma revierte la transacción y reporta `ABORTED_NO_COMMIT`. Confirmar `APPLIED` solo cuando el CLI termine con éxito; volver a correr exige un nuevo backup y debe contar las filas ya idénticas sin crear duplicados.

## Guardas y límites

El importador compara hostname/base con valores de confirmación explícitos, exige la identidad de aplicación, archivo custom-format legible, SHA-256 correcto y nombre de base del dump; exige las 10 migraciones versionadas del repo y verifica que el esquema no sea tenantizado. Códigos SIESA e internos son claves de deduplicación. Si los 39 productos UI no coinciden exactamente con los 39 códigos fuente, si cualquier valor del código existente difiere, si hay referencias de ingredientes sin match o perfil ambiguo, la transacción se aborta. No fuerza compatibilidad de negocio ni corrige unidades.

No incluye ni modifica código del repo. No ejecuta seeds demo, no crea aprobaciones, no importa los parámetros regulatorios ni los costos. El rol/fila de producto de destino debe ser compatible con el schema Prisma del checkout; la guarda de migraciones rechaza una versión distinta. Pruebas offline no certifican acceso a producción, identidad real del host ni coincidencia de los 39 productos UI.

El repositorio tiene un remoto `meeteam` con visibilidad pública confirmada y un remoto `origin` que GitHub no resolvió al consultar metadatos. Por eso el paquete y sus datos se mantienen como archivo privado en Library; no se añade el dataset ni el script a esos remotos.
