#!/usr/bin/env python3
"""Offline integrity/dependency checks for the sanitized Alimentos Sevilla payload."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
d = json.loads((ROOT / "data/payload.json").read_text(encoding="utf-8"))
errors = []
def unique(rows, key, label):
    seen = set()
    for r in rows:
        k = key(r)
        if k in seen: errors.append(f"duplicate {label}: {k}")
        seen.add(k)
unique(d['ingredients'], lambda x:x['siesaCode'], 'ingredient siesaCode')
unique(d['products'], lambda x:x['internalCode'], 'product internalCode')
unique(d['nutrientCatalog'], lambda x:x['key'], 'nutrient key')
unique(d['formulationVersions'], lambda x:(x['productCode'],x['sequence']), 'formulation version')
products={x['internalCode'] for x in d['products']}
ingredients={x['siesaCode'] for x in d['ingredients']}
versions={(x['productCode'],x['sequence']) for x in d['formulationVersions']}
for label, rows, field in [('presentation',d['presentations'],'productCode'),('formulation',d['formulations'],'productCode'),('formulation version',d['formulationVersions'],'productCode')]:
    for r in rows:
        if r[field] not in products: errors.append(f"{label} missing product {r[field]}")
for c in d['formulationIngredients']:
    if (c['productCode'],c['versionSequence']) not in versions: errors.append(f"component missing version {(c['productCode'],c['versionSequence'])}")
    if c['ingredientSiesaCode'] not in ingredients: errors.append(f"unmapped component ingredient {c['ingredientSiesaCode']} on {c['productCode']} v{c['versionSequence']}")
for p in d['nutritionalProfiles']:
    if p['ingredientSiesaCode'] not in ingredients: errors.append(f"profile missing ingredient {p['ingredientSiesaCode']}")
    if 'TN OFICIAL' not in (p.get('sourceDetail') or '').upper(): errors.append(f"profile provenance not explicit {p['localProfileId']}")
    if p.get('source') not in ('BANCO_ALIMENTOS','LAB_PROVEEDOR','LITERATURA'): errors.append(f"invalid profile source {p['localProfileId']}")
for v in d['formulationVersions']:
    if v['status'] != 'DRAFT' or v.get('approvedAt') or v.get('hasApprover'): errors.append(f"version is not safely staged as DRAFT {v['localId']}")
print(json.dumps({'snapshotAt':d['snapshotAt'],'counts':{k:len(d[k]) for k in ('ingredients','products','presentations','nutrientCatalog','nutritionalProfiles','formulations','formulationVersions','formulationIngredients')},'errors':errors,'status':'FAIL' if errors else 'PASS','scope':'offline only; no target DB connection'},ensure_ascii=False,indent=2))
raise SystemExit(1 if errors else 0)
